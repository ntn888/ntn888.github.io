#include <stdio.h>
#include <hosal_gpio.h>
#include <FreeRTOS.h>
#include <task.h>

static hosal_gpio_dev_t gp1;

void main (void)
{
   // setup
   gp1.port = 0; // <== make sure led connected to pin D0!
   gp1.config = OUTPUT_OPEN_DRAIN_NO_PULL;
   hosal_gpio_init(&gp1);
   hosal_gpio_output_set(&gp1, 1);

   uint8_t value = 1;

   while (1) {
      hosal_gpio_output_set(&gp1, value );
      value = !value;
      vTaskDelay(500);
   }
}
